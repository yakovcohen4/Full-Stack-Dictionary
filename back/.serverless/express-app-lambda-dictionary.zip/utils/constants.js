// Essential information that does NOT change

// Table name in DynamoDB
const TABLE_NAME = 'dictionary';

// Region
const REGION = 'eu-west-1';

module.exports = { TABLE_NAME, REGION };
